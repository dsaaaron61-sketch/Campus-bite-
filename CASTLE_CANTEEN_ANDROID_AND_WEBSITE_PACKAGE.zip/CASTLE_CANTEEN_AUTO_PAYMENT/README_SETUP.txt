CASTLE CANTEEN — AUTOMATIC CASHFREE PAYMENT VERIFICATION

WHAT IS INCLUDED
- Existing Castle Canteen UI, menu, food photos, student/admin screens and cart.
- UPI and card checkout through Cashfree hosted checkout.
- Server-side order creation with server-owned menu prices (menu.json).
- Server-side payment-status checks and signed webhook verification.
- Backend re-fetches Cashfree order/payment state and checks amount before marking PAID.
- SQLite payment/order records. Cash-at-counter flow remains available.

IMPORTANT
This is a ready-to-configure integration package, not an activated Cashfree merchant account. Real automatic verification requires your own Cashfree merchant account, API credentials, public HTTPS hosting and webhook configuration. It defaults to SANDBOX and no credentials are included.

WINDOWS SANDBOX SETUP
1. Install Python 3.10+.
2. Double-click run_windows.bat. It creates a virtual environment and installs requirements.
3. Open the created .env file in Notepad and enter your Cashfree SANDBOX App ID and Secret Key. Keep them private.
4. Keep CASHFREE_ENV=sandbox and PUBLIC_BASE_URL=http://127.0.0.1:5000 for local development.
5. In Command Prompt in this folder run: .venv\Scripts\activate then python app.py
6. Open http://127.0.0.1:5000. Do not open index.html directly as a file.
7. Test using Cashfree's current sandbox test methods and credentials from the official dashboard/docs.

LIVE SETUP
1. Deploy app.py, index.html, menu.json and requirements.txt to Python hosting with HTTPS.
2. Set CASHFREE_ENV=production, production API credentials, and PUBLIC_BASE_URL=https://YOUR-DOMAIN.
3. Configure Cashfree webhook URL: https://YOUR-DOMAIN/api/payments/webhook and enable payment success events.
4. Ensure your return URL domain is accepted in Cashfree settings.
5. Test and reconcile with Cashfree dashboard before allowing student orders.

MENU PRICE RULE
menu.json is the trusted server-side price list. Update it on the server whenever admin changes menu prices. Browser-submitted prices are never trusted.

SECURITY
- Never put API secrets in index.html or share them in chat.
- Never collect card number, CVV, OTP, UPI PIN or ATM PIN in this app. Cashfree hosted checkout handles these securely.
- A redirect or screenshot is not proof of payment. Backend requires Cashfree order status PAID and a successful payment amount match.
- Before public launch add production authentication for admin/student accounts, rate limiting, backups and monitoring. The inherited login/admin screens still use browser localStorage and are not production-secure.

OFFICIAL DOCS
https://www.cashfree.com/devstudio/preview/pg/web/checkout
https://docs.cashfree.com/reference/pg-new-apis-endpoint
https://github.com/cashfree/cashfree-pg-sdk-nodejs
