CASTLE CANTEEN Android wrapper project (source, not compiled APK)

Open this android-app folder in Android Studio. Allow Gradle sync and install SDK components it requests. Choose Build > Build Bundle(s) / APK(s) > Build APK(s). APK output: app/build/outputs/apk/debug/app-debug.apk.

This bundles the app UI for demo. The Cashfree backend is not bundled; automatic payment verification requires the Flask server on public HTTPS with merchant credentials. The packaged local UI will not perform real gateway payments until configured to call your hosted backend. Never put Cashfree secrets in the app.
