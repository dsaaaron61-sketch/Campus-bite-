CASTLE CANTEEN — Android + website package

WEBSITE: PWA manifest, install icons and service worker are included. Run the Flask server using README_SETUP.txt and open http://127.0.0.1:5000 on the same computer. To get a public direct-opening link, deploy this project to a public HTTPS host; a public URL cannot be generated without a hosting account/deployment. After hosting, open the URL in Android Chrome and choose menu > Install app / Add to Home screen.

ANDROID: Open android-app folder in Android Studio and follow BUILD_APK_README.txt. This environment has no Android SDK/Gradle build tools, so no compiled APK could be produced here; Android Studio source is included.

PAYMENTS: Cashfree backend still needs credentials and public HTTPS hosting. Packaging does not activate real payment verification.
