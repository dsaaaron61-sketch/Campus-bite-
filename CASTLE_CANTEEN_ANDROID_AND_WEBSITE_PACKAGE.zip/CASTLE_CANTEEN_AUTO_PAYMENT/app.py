import os, json, re, uuid, hmac, hashlib, base64, sqlite3, logging
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
import requests
from flask import Flask, request, jsonify, send_from_directory
from dotenv import load_dotenv
ROOT=Path(__file__).resolve().parent
load_dotenv(ROOT/'.env')
app=Flask(__name__,static_folder=None)
app.config['MAX_CONTENT_LENGTH']=1_000_000
logging.basicConfig(level=logging.INFO)
ENV=os.getenv('CASHFREE_ENV','sandbox').strip().lower()
if ENV not in ('sandbox','production'): raise RuntimeError('CASHFREE_ENV must be sandbox or production')
BASE='https://sandbox.cashfree.com/pg' if ENV=='sandbox' else 'https://api.cashfree.com/pg'
CLIENT_ID=os.getenv('CASHFREE_CLIENT_ID','').strip(); CLIENT_SECRET=os.getenv('CASHFREE_CLIENT_SECRET','').strip()
API_VERSION=os.getenv('CASHFREE_API_VERSION','2025-01-01').strip()
PUBLIC_BASE_URL=os.getenv('PUBLIC_BASE_URL','http://127.0.0.1:5000').rstrip('/')
DB=ROOT/'castle_canteen_payments.sqlite3'
MENU={str(x['id']):x for x in json.loads((ROOT/'menu.json').read_text(encoding='utf-8'))}
class GatewayError(Exception): pass
def db():
 c=sqlite3.connect(DB,timeout=20); c.row_factory=sqlite3.Row; return c
def init_db():
 with db() as c:
  c.execute('''CREATE TABLE IF NOT EXISTS orders(order_id TEXT PRIMARY KEY,name TEXT NOT NULL,student_id TEXT NOT NULL,phone TEXT NOT NULL,pickup TEXT NOT NULL,note TEXT,amount TEXT NOT NULL,payment_method TEXT NOT NULL,items_json TEXT NOT NULL,payment_status TEXT NOT NULL DEFAULT 'PENDING',cf_payment_id TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)''')
  c.execute('''CREATE TABLE IF NOT EXISTS webhook_events(event_key TEXT PRIMARY KEY,received_at TEXT NOT NULL)''')
def cf_headers():
 if not CLIENT_ID or not CLIENT_SECRET: raise GatewayError('Cashfree API credentials are missing. Add them to .env.')
 return {'x-client-id':CLIENT_ID,'x-client-secret':CLIENT_SECRET,'x-api-version':API_VERSION,'Content-Type':'application/json','Accept':'application/json'}
def cf_request(method,path,**kwargs):
 try:r=requests.request(method,BASE+path,headers=cf_headers(),timeout=25,**kwargs)
 except requests.RequestException as e: raise GatewayError('Could not connect to Cashfree. Please retry.') from e
 try:d=r.json()
 except ValueError:d={}
 if not r.ok:
  app.logger.warning('Cashfree error %s: %s',r.status_code,d); raise GatewayError(d.get('message') or d.get('type') or 'Cashfree rejected the request')
 return d
def verify_signature(raw,timestamp,signature):
 if not timestamp or not signature or not CLIENT_SECRET:return False
 digest=hmac.new(CLIENT_SECRET.encode(),timestamp.encode()+raw,hashlib.sha256).digest()
 return hmac.compare_digest(base64.b64encode(digest).decode(),signature)
def authoritative_status(order_id):
 order=cf_request('GET','/orders/'+order_id); payments=cf_request('GET','/orders/'+order_id+'/payments')
 amount=Decimal(str(order.get('order_amount','0'))); success=None
 for p in payments if isinstance(payments,list) else []:
  if p.get('payment_status')=='SUCCESS':
   try:paid_amount=Decimal(str(p.get('payment_amount','0')))
   except InvalidOperation:continue
   if paid_amount==amount:success=p;break
 return order.get('order_status')=='PAID' and success is not None,order,success
def mark_paid(order_id,payment_id=None):
 with db() as c:c.execute("UPDATE orders SET payment_status='PAID',cf_payment_id=COALESCE(?,cf_payment_id),updated_at=? WHERE order_id=?",(str(payment_id) if payment_id else None,datetime.now(timezone.utc).isoformat(),order_id))
def get_local_order(order_id):
 with db() as c:r=c.execute('SELECT * FROM orders WHERE order_id=?',(order_id,)).fetchone()
 if not r:return None
 return {'order_id':r['order_id'],'name':r['name'],'student_id':r['student_id'],'phone':r['phone'],'pickup':r['pickup'],'note':r['note'] or '','amount':float(r['amount']),'payment_method':r['payment_method'],'items':json.loads(r['items_json']),'cf_payment_id':r['cf_payment_id'],'created_at':r['created_at'],'status':r['payment_status']}
@app.get('/')
def index():return send_from_directory(ROOT,'index.html')
@app.get('/<path:path>')
def static(path):
 if path in ('index.html','menu.json'):return send_from_directory(ROOT,path)
 return 'Not found',404
@app.get('/api/health')
def health():return jsonify(ok=True,gateway='Cashfree',mode=ENV,credentials_configured=bool(CLIENT_ID and CLIENT_SECRET),public_https=PUBLIC_BASE_URL.startswith('https://'))
@app.post('/api/payments/create-order')
def create_order():
 d=request.get_json(silent=True) or {}; name=str(d.get('name','')).strip()[:80]; sid=str(d.get('student_id','')).strip()[:40]; phone=re.sub(r'\D','',str(d.get('phone','')))
 if not name or not sid or not re.fullmatch(r'\d{10}',phone):return jsonify(error='Enter student name, USN/roll number and a valid 10-digit mobile number.'),400
 lines=d.get('items')
 if not isinstance(lines,list) or not lines or len(lines)>30:return jsonify(error='Cart is empty or invalid.'),400
 items=[];total=Decimal('0.00')
 for line in lines:
  try:key=str(int(line.get('id')));qty=int(line.get('quantity'))
  except (TypeError,ValueError,AttributeError):return jsonify(error='Invalid cart item.'),400
  if key not in MENU or qty<1 or qty>20:return jsonify(error='Invalid menu item or quantity.'),400
  f=MENU[key];price=Decimal(str(f['price']));total+=price*qty;items.append({'id':int(key),'name':f['name'],'q':qty,'price':float(price)})
 if total<=0 or total>Decimal('50000'):return jsonify(error='Order amount is outside permitted range.'),400
 oid='castle_'+uuid.uuid4().hex[:24];now=datetime.now(timezone.utc).isoformat();pickup=str(d.get('pickup','As soon as ready'))[:40];note=str(d.get('note',''))[:250];method='CARD' if d.get('payment_method')=='card' else 'UPI'
 payload={'order_id':oid,'order_amount':float(total),'order_currency':'INR','customer_details':{'customer_id':re.sub(r'\W','',sid)[:50] or oid,'customer_name':name,'customer_phone':phone},'order_meta':{'return_url':PUBLIC_BASE_URL+'/?order_id={order_id}','notify_url':PUBLIC_BASE_URL+'/api/payments/webhook'},'order_note':('Castle Canteen '+method+' | '+sid)[:250]}
 try:result=cf_request('POST','/orders',json=payload)
 except GatewayError as e:return jsonify(error=str(e)),502
 session=result.get('payment_session_id')
 if not session:return jsonify(error='Cashfree did not return a payment session.'),502
 with db() as c:c.execute("INSERT INTO orders(order_id,name,student_id,phone,pickup,note,amount,payment_method,items_json,payment_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,'PENDING',?,?)",(oid,name,sid,phone,pickup,note,str(total),method,json.dumps(items),now,now))
 return jsonify(order_id=oid,payment_session_id=session,mode='production' if ENV=='production' else 'sandbox',amount=float(total))
@app.get('/api/payments/status/<order_id>')
def payment_status(order_id):
 local=get_local_order(order_id)
 if not local:return jsonify(error='Order not found',status='NOT_FOUND'),404
 if local['status']!='PAID':
  try:
   paid,co,p=authoritative_status(order_id)
   if paid:mark_paid(order_id,p.get('cf_payment_id'));local=get_local_order(order_id)
   elif co.get('order_status') in ('EXPIRED','TERMINATED'):
    with db() as c:c.execute("UPDATE orders SET payment_status='EXPIRED',updated_at=? WHERE order_id=?",(datetime.now(timezone.utc).isoformat(),order_id))
    local=get_local_order(order_id)
  except GatewayError as e:app.logger.warning('Status check issue for %s: %s',order_id,e)
 if local['status']=='PAID':return jsonify(status='PAID',order={k:local[k] for k in ('order_id','name','student_id','amount','pickup','note','payment_method','items','cf_payment_id','created_at')})
 return jsonify(status=local['status'])
@app.post('/api/payments/webhook')
def webhook():
 raw=request.get_data(cache=False,as_text=False);ts=request.headers.get('x-webhook-timestamp','');sig=request.headers.get('x-webhook-signature','')
 if not verify_signature(raw,ts,sig):return jsonify(error='Invalid webhook signature'),400
 try:event=json.loads(raw.decode('utf-8'))
 except (ValueError,UnicodeDecodeError):return jsonify(error='Invalid JSON'),400
 data=event.get('data') or {};order=(data.get('order') or {});payment=(data.get('payment') or {});oid=order.get('order_id')
 if not oid:return jsonify(ok=True,ignored=True)
 key=str(payment.get('cf_payment_id') or (event.get('type','event')+':'+oid+':'+ts))
 with db() as c:
  if c.execute('SELECT 1 FROM webhook_events WHERE event_key=?',(key,)).fetchone():return jsonify(ok=True,duplicate=True)
 try:paid,co,p=authoritative_status(oid)
 except GatewayError as e:app.logger.error('Webhook verification unavailable: %s',e);return jsonify(error='Temporary verification error; retry webhook'),500
 with db() as c:c.execute('INSERT OR IGNORE INTO webhook_events(event_key,received_at) VALUES(?,?)',(key,datetime.now(timezone.utc).isoformat()))
 if paid:mark_paid(oid,p.get('cf_payment_id'))
 return jsonify(ok=True,verified=paid)
init_db()
if __name__=='__main__':
 app.run(host='127.0.0.1',port=int(os.getenv('PORT','5000')),debug=False)
